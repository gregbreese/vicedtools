from vicedtools.gwsc.reports import (work_habits_result_mapper, 
                                     learning_tasks_result_mapper, 
                                     progress_report_result_mapper, 
                                     results_dtype, 
                                     progress_report_items,
                                     class_code_parser)